<?php

namespace Pterodactyl\Console\Commands\Store;

use Illuminate\Console\Command;
use Pterodactyl\Models\Server;
use Pterodactyl\Services\WhatsApp\WhatsAppNotifierService;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;
use Carbon\Carbon;

class SendDailyReportCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'p:store:daily-report';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send daily server status report to the WhatsApp group at midnight.';

    private WhatsAppNotifierService $whatsAppNotifier;
    private SettingsRepositoryInterface $settings;

    /**
     * Create a new command instance.
     */
    public function __construct(WhatsAppNotifierService $whatsAppNotifier, SettingsRepositoryInterface $settings)
    {
        parent::__construct();
        $this->whatsAppNotifier = $whatsAppNotifier;
        $this->settings = $settings;
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        // Wajib setting group dulu
        $groupJid = $this->settings->get('wa_bot:group_jid', '');
        if (empty($groupJid)) {
            $this->warn('Group JID belum di-setting. Cron daily report tidak jalan. Silakan setting group dulu via bot (setgroup).');
            return 0;
        }

        $botName = strtoupper($this->settings->get('wa_bot:bot_name', config('app.name', 'PANEL BOT')));
        $now = Carbon::now();
        $mentions = [];

        // =============================================
        // 1. SERVER AKTIF (belum expired, punya expiry)
        // =============================================
        $activeServers = Server::with('user')
            ->whereNotNull('store_expires_at')
            ->where('store_expires_at', '>', $now)
            ->where(function ($q) {
                $q->whereNull('status')
                  ->orWhere('status', '!=', Server::STATUS_SUSPENDED);
            })
            ->orderBy('store_expires_at', 'asc')
            ->get();

        // =============================================
        // 2. SERVER MAU EXPIRED (expired dalam 3 hari)
        // =============================================
        $soonExpiring = Server::with('user')
            ->whereNotNull('store_expires_at')
            ->where('store_expires_at', '>', $now)
            ->where('store_expires_at', '<=', $now->copy()->addDays(3))
            ->where(function ($q) {
                $q->whereNull('status')
                  ->orWhere('status', '!=', Server::STATUS_SUSPENDED);
            })
            ->orderBy('store_expires_at', 'asc')
            ->get();

        // =============================================
        // 3. SERVER SUDAH EXPIRED (suspended, dalam masa tenggang 3 hari)
        // =============================================
        $expiredServers = Server::with('user')
            ->whereNotNull('store_expires_at')
            ->where('store_expires_at', '<', $now)
            ->where('status', Server::STATUS_SUSPENDED)
            ->orderBy('store_expires_at', 'asc')
            ->get();

        // =============================================
        // 4. SERVER PERMANENT (tanpa expiry)
        // =============================================
        $permanentServers = Server::with('user')
            ->whereNull('store_expires_at')
            ->where(function ($q) {
                $q->whereNull('status')
                  ->orWhere('status', '!=', Server::STATUS_SUSPENDED);
            })
            ->get();

        // =============================================
        // BUILD MESSAGE
        // =============================================
        $dateStr = $now->translatedFormat('l, d F Y');

        $message = "⚡ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ ⚡\n";
        $message .= "🤖 *{$botName} — DAILY SERVER REPORT*\n";
        $message .= "📅 {$dateStr}\n";
        $message .= "⚡ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ ⚡\n\n";

        // ── SECTION: SERVER MAU EXPIRED ──
        $message .= "⚠️ *SERVER MAU EXPIRED (≤ 3 HARI):*\n";
        $message .= "─────────────────────────\n";
        if ($soonExpiring->isEmpty()) {
            $message .= "✅ Tidak ada server yang mau expired.\n\n";
        } else {
            $count = 1;
            foreach ($soonExpiring as $server) {
                $user = $server->user;
                $phoneTag = $this->buildPhoneTag($user, $mentions);
                $expiryDate = Carbon::parse($server->store_expires_at);
                $sisaHari = (int) $now->diffInDays($expiryDate, false);
                $sisaStr = $sisaHari <= 0 ? 'HARI INI!' : "{$sisaHari} hari lagi";
                $dateFormatted = $expiryDate->translatedFormat('d F Y');

                $message .= "{$count}. 🎮 *{$server->name}*\n";
                $message .= "   🆔 ID: `{$server->id}` | 👤 {$phoneTag}\n";
                $message .= "   📅 Expired: {$dateFormatted} (⏳ {$sisaStr})\n\n";
                $count++;
            }
        }

        // ── SECTION: SERVER SUDAH EXPIRED (SUSPENDED) ──
        $message .= "🔴 *SERVER SUDAH EXPIRED (SUSPENDED):*\n";
        $message .= "─────────────────────────\n";
        if ($expiredServers->isEmpty()) {
            $message .= "✅ Tidak ada server yang suspended.\n\n";
        } else {
            $count = 1;
            foreach ($expiredServers as $server) {
                $user = $server->user;
                $phoneTag = $this->buildPhoneTag($user, $mentions);
                $expiryDate = Carbon::parse($server->store_expires_at);
                $hariSejakExpired = (int) $now->diffInDays($expiryDate);
                $sisaHariDelete = 3 - $hariSejakExpired;
                $dateFormatted = $expiryDate->translatedFormat('d F Y');

                if ($sisaHariDelete <= 0) {
                    $deleteStr = "🗑️ *AKAN DIHAPUS HARI INI!*";
                } else {
                    $deleteStr = "⏳ Auto-delete dalam {$sisaHariDelete} hari";
                }

                $message .= "{$count}. 🎮 *{$server->name}*\n";
                $message .= "   🆔 ID: `{$server->id}` | 👤 {$phoneTag}\n";
                $message .= "   📅 Expired: {$dateFormatted}\n";
                $message .= "   {$deleteStr}\n\n";
                $count++;
            }
        }

        // ── SECTION: SERVER AKTIF ──
        $message .= "🟢 *SERVER AKTIF:*\n";
        $message .= "─────────────────────────\n";

        // Permanent servers
        if ($permanentServers->isNotEmpty()) {
            foreach ($permanentServers as $server) {
                $user = $server->user;
                $phoneTag = $this->buildPhoneTag($user, $mentions);
                $message .= "• 🎮 *{$server->name}* — 👤 {$phoneTag}\n";
                $message .= "  🆔 ID: `{$server->id}` | ♾️ Permanen\n";
            }
        }

        // Active servers with expiry
        $activeNonSoon = $activeServers->filter(function ($s) use ($now) {
            return Carbon::parse($s->store_expires_at)->diffInDays($now, false) < -3;
        });

        if ($activeNonSoon->isNotEmpty()) {
            foreach ($activeNonSoon as $server) {
                $user = $server->user;
                $phoneTag = $this->buildPhoneTag($user, $mentions);
                $expiryDate = Carbon::parse($server->store_expires_at);
                $sisaHari = (int) $now->diffInDays($expiryDate, false);
                $dateFormatted = $expiryDate->translatedFormat('d F Y');

                $message .= "• 🎮 *{$server->name}* — 👤 {$phoneTag}\n";
                $message .= "  🆔 ID: `{$server->id}` | 📅 {$dateFormatted} ({$sisaHari} hari)\n";
            }
        }

        if ($permanentServers->isEmpty() && $activeNonSoon->isEmpty()) {
            $message .= "Tidak ada server aktif saat ini.\n";
        }

        $message .= "\n";

        // ── SECTION: RINGKASAN ──
        $totalAll = Server::count();
        $message .= "📊 ━━━ *RINGKASAN* ━━━ 📊\n";
        $message .= "🟢 Aktif         : {$activeServers->count()} server\n";
        $message .= "♾️ Permanen      : {$permanentServers->count()} server\n";
        $message .= "⚠️ Mau Expired   : {$soonExpiring->count()} server\n";
        $message .= "🔴 Suspended     : {$expiredServers->count()} server\n";
        $message .= "📦 Total Server  : {$totalAll} server\n\n";

        $message .= "💡 *Catatan:*\n";
        $message .= "• Server yang expired akan otomatis di-suspend\n";
        $message .= "• Batas perpanjangan: *3 hari* setelah expired\n";
        $message .= "• Lebih dari 3 hari → *otomatis dihapus permanen*\n\n";
        $message .= "⚡ *{$botName} CRON SYSTEM* — {$now->format('H:i')} WIB";

        $mentions = array_unique($mentions);

        $this->whatsAppNotifier->sendToGroup($message, array_values($mentions));
        $this->info('Daily report sent successfully to group.');

        return 0;
    }

    /**
     * Build a phone tag for mentioning user in WhatsApp group.
     */
    private function buildPhoneTag($user, array &$mentions): string
    {
        if (!$user || empty($user->phone)) {
            return $user ? $user->email : 'Unknown';
        }

        $phone = $this->whatsAppNotifier->formatPhoneNumber($user->phone);
        $mentions[] = $phone . '@s.whatsapp.net';
        return "@{$phone}";
    }
}
