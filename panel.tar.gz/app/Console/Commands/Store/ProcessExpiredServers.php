<?php

namespace Pterodactyl\Console\Commands\Store;

use Illuminate\Console\Command;
use Pterodactyl\Models\Server;
use Pterodactyl\Services\Servers\ServerDeletionService;
use Pterodactyl\Services\Servers\SuspensionService;
use Pterodactyl\Services\WhatsApp\WhatsAppNotifierService;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;
use Carbon\Carbon;

class ProcessExpiredServers extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'store:process-expired';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Process expired servers from the store (suspend or delete) with WhatsApp group notifications.';

    private ServerDeletionService $deletionService;
    private SuspensionService $suspensionService;
    private WhatsAppNotifierService $whatsAppNotifier;
    private SettingsRepositoryInterface $settings;

    /**
     * Create a new command instance.
     */
    public function __construct(
        ServerDeletionService $deletionService,
        SuspensionService $suspensionService,
        WhatsAppNotifierService $whatsAppNotifier,
        SettingsRepositoryInterface $settings
    ) {
        parent::__construct();
        $this->deletionService = $deletionService;
        $this->suspensionService = $suspensionService;
        $this->whatsAppNotifier = $whatsAppNotifier;
        $this->settings = $settings;
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $groupJid = $this->settings->get('wa_bot:group_jid', '');
        $botName = strtoupper($this->settings->get('wa_bot:bot_name', config('app.name', 'PANEL BOT')));
        $hasGroup = !empty($groupJid);

        $suspendedList = [];
        $deletedList = [];

        // =============================================
        // 1. SUSPEND: Servers expired but not yet suspended
        // =============================================
        $expiredToSuspend = Server::with('user')
            ->whereNotNull('store_expires_at')
            ->where('store_expires_at', '<', now())
            ->where(function ($q) {
                $q->whereNull('status')
                  ->orWhere('status', '!=', Server::STATUS_SUSPENDED);
            })
            ->get();

        foreach ($expiredToSuspend as $server) {
            $this->info("Suspending server {$server->uuidShort} due to expiration.");
            try {
                $this->suspensionService->toggle($server, SuspensionService::ACTION_SUSPEND);
            } catch (\Exception $e) {
                // Fallback: update status directly if Wings sync fails
                $server->update(['status' => Server::STATUS_SUSPENDED]);
                $this->warn("Wings sync failed for {$server->uuidShort}, suspended locally: {$e->getMessage()}");
            }

            $user = $server->user;
            $suspendedList[] = [
                'server' => $server,
                'user' => $user,
            ];
        }

        // =============================================
        // 2. DELETE: Servers expired > 3 days and suspended
        // =============================================
        $expiredToDelete = Server::with('user')
            ->whereNotNull('store_expires_at')
            ->where('store_expires_at', '<', now()->subDays(3))
            ->where('status', Server::STATUS_SUSPENDED)
            ->get();

        foreach ($expiredToDelete as $server) {
            $this->info("Deleting server {$server->uuidShort} because it was expired for 3+ days.");
            $user = $server->user;
            $serverName = $server->name;
            $serverId = $server->id;
            $expiryDate = $server->store_expires_at ? Carbon::parse($server->store_expires_at)->translatedFormat('d F Y') : '-';

            try {
                $this->deletionService->withForce()->handle($server);
                $deletedList[] = [
                    'name' => $serverName,
                    'id' => $serverId,
                    'user' => $user,
                    'expiry' => $expiryDate,
                ];
            } catch (\Exception $e) {
                $this->error("Failed to delete server {$server->uuidShort}: {$e->getMessage()}");
            }
        }

        // =============================================
        // 3. SEND GROUP NOTIFICATION (if group is set)
        // =============================================
        if ($hasGroup && (!empty($suspendedList) || !empty($deletedList))) {
            $mentions = [];
            $now = Carbon::now();

            $message = "🔔 ━━━ *{$botName} AUTO-CRON* ━━━ 🔔\n";
            $message .= "📅 {$now->translatedFormat('d F Y H:i')} WIB\n\n";

            // Suspended servers notification
            if (!empty($suspendedList)) {
                $message .= "🟡 *SERVER BARU DI-SUSPEND:*\n";
                $message .= "─────────────────────────\n";
                $count = 1;
                foreach ($suspendedList as $item) {
                    $phoneTag = $this->buildPhoneTag($item['user'], $mentions);
                    $message .= "{$count}. 🎮 *{$item['server']->name}*\n";
                    $message .= "   🆔 ID: `{$item['server']->id}` | 👤 {$phoneTag}\n";
                    $message .= "   ⏳ Batas perpanjangan: *3 hari*\n\n";
                    $count++;
                }
            }

            // Deleted servers notification
            if (!empty($deletedList)) {
                $message .= "🗑️ *SERVER DIHAPUS OTOMATIS:*\n";
                $message .= "─────────────────────────\n";
                $count = 1;
                foreach ($deletedList as $item) {
                    $phoneTag = $this->buildPhoneTag($item['user'], $mentions);
                    $message .= "{$count}. 🎮 *{$item['name']}*\n";
                    $message .= "   🆔 ID: `{$item['id']}` | 👤 {$phoneTag}\n";
                    $message .= "   📅 Expired sejak: {$item['expiry']}\n";
                    $message .= "   ❌ *Dihapus permanen karena melebihi batas 3 hari*\n\n";
                    $count++;
                }
            }

            $message .= "⚡ *{$botName} CRON SYSTEM*";

            $mentions = array_unique($mentions);
            $this->whatsAppNotifier->sendToGroup($message, array_values($mentions));
            $this->info('Group notification sent for suspend/delete actions.');
        }

        return 0;
    }

    /**
     * Build a phone tag for mentioning user in WhatsApp group.
     */
    private function buildPhoneTag($user, array &$mentions): string
    {
        if (!$user || empty($user->phone)) {
            return $user ? $user->email : 'Unknown';
        }

        $phone = $this->whatsAppNotifier->formatPhoneNumber($user->phone);
        $mentions[] = $phone . '@s.whatsapp.net';
        return "@{$phone}";
    }
}
