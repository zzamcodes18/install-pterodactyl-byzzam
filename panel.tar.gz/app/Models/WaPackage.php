<?php

namespace Pterodactyl\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;

class WaPackage extends Model
{
    use HasFactory;

    /**
     * The resource name for this model.
     */
    public const RESOURCE_NAME = 'wa_package';

    protected $table = 'wa_packages';

    protected $fillable = [
        'name',
        'description',
        'price',
        'duration_days',
        'daily_limit',
        'weekly_limit',
        'monthly_limit',
        'is_active',
    ];

    protected $casts = [
        'price' => 'integer',
        'duration_days' => 'integer',
        'daily_limit' => 'integer',
        'weekly_limit' => 'integer',
        'monthly_limit' => 'integer',
        'is_active' => 'boolean',
    ];

    public static array $validationRules = [
        'name' => 'required|string|max:191',
        'description' => 'nullable|string',
        'price' => 'required|integer|min:0',
        'duration_days' => 'required|integer|min:1',
        'daily_limit' => 'required|integer|min:0',
        'weekly_limit' => 'required|integer|min:0',
        'monthly_limit' => 'required|integer|min:0',
        'is_active' => 'boolean',
    ];

    public function subscriptions()
    {
        return $this->hasMany(UserWaSubscription::class, 'wa_package_id');
    }
}
