<?php

namespace Pterodactyl\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class WaMessageLog extends Model
{
    use HasFactory;

    public const RESOURCE_NAME = 'wa_message_log';

    protected $table = 'wa_message_logs';

    protected $fillable = [
        'subscription_id',
        'user_id',
        'recipient',
        'message',
        'status',
    ];

    public function subscription(): BelongsTo
    {
        return $this->belongsTo(UserWaSubscription::class, 'subscription_id');
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
