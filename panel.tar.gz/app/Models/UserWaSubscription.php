<?php

namespace Pterodactyl\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class UserWaSubscription extends Model
{
    use HasFactory;

    public const RESOURCE_NAME = 'user_wa_subscription';

    protected $table = 'user_wa_subscriptions';

    protected $fillable = [
        'user_id',
        'wa_package_id',
        'session_id',
        'api_key',
        'status',
        'phone_number',
        'messages_sent_today',
        'messages_sent_week',
        'messages_sent_month',
        'daily_reset_at',
        'weekly_reset_at',
        'monthly_reset_at',
        'expires_at',
        'is_active',
    ];

    protected $casts = [
        'messages_sent_today' => 'integer',
        'messages_sent_week' => 'integer',
        'messages_sent_month' => 'integer',
        'is_active' => 'boolean',
        'daily_reset_at' => 'datetime',
        'weekly_reset_at' => 'datetime',
        'monthly_reset_at' => 'datetime',
        'expires_at' => 'datetime',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function package(): BelongsTo
    {
        return $this->belongsTo(WaPackage::class, 'wa_package_id');
    }

    public function logs(): HasMany
    {
        return $this->hasMany(WaMessageLog::class, 'subscription_id');
    }
}
