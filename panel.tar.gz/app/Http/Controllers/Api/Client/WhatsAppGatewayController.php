<?php

namespace Pterodactyl\Http\Controllers\Api\Client;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Pterodactyl\Models\WaPackage;
use Pterodactyl\Models\UserWaSubscription;
use Pterodactyl\Models\WaMessageLog;
use Pterodactyl\Exceptions\DisplayException;
use Illuminate\Support\Str;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Http;

class WhatsAppGatewayController extends ClientApiController
{
    private string $botUrl = 'http://127.0.0.1:3001';

    /**
     * Get user WhatsApp subscription, active packages, and usage quota statistics.
     */
    public function index(Request $request): JsonResponse
    {
        $user = $request->user();

        $subscription = UserWaSubscription::with('package')
            ->where('user_id', $user->id)
            ->where('is_active', true)
            ->first();

        // Auto reset quotas if day/week/month changed
        if ($subscription) {
            $now = Carbon::now();

            if (!$subscription->daily_reset_at || $now->isAfter($subscription->daily_reset_at)) {
                $subscription->messages_sent_today = 0;
                $subscription->daily_reset_at = $now->copy()->endOfDay();
            }

            if (!$subscription->weekly_reset_at || $now->isAfter($subscription->weekly_reset_at)) {
                $subscription->messages_sent_week = 0;
                $subscription->weekly_reset_at = $now->copy()->endOfWeek();
            }

            if (!$subscription->monthly_reset_at || $now->isAfter($subscription->monthly_reset_at)) {
                $subscription->messages_sent_month = 0;
                $subscription->monthly_reset_at = $now->copy()->endOfMonth();
            }

            // Check expiration
            if ($subscription->expires_at && $now->isAfter($subscription->expires_at)) {
                $subscription->is_active = false;
            }

            $subscription->save();
        }

        $packages = WaPackage::where('is_active', true)->get();

        return new JsonResponse([
            'subscription' => $subscription,
            'packages' => $packages,
            'balance' => $user->store_balance ?? 0,
        ]);
    }

    /**
     * Purchase or renew a WhatsApp Gateway commercial plan.
     */
    public function purchase(Request $request): JsonResponse
    {
        $request->validate([
            'package_id' => 'required|integer|exists:wa_packages,id',
        ]);

        $user = $request->user();
        $package = WaPackage::where('is_active', true)->findOrFail($request->input('package_id'));

        $userBalance = $user->store_balance ?? 0;
        if ($userBalance < $package->price) {
            throw new DisplayException('Saldo tidak mencukupi untuk membeli paket WhatsApp Gateway ini.');
        }

        // Deduct user balance
        $user->store_balance = $userBalance - $package->price;
        $user->save();

        // Find existing subscription or create new
        $subscription = UserWaSubscription::where('user_id', $user->id)->first();
        $sessionId = 'user_' . $user->id . '_' . Str::random(8);
        $apiKey = 'wa_api_' . Str::random(32);

        $expiresAt = Carbon::now()->addDays($package->duration_days);

        if ($subscription) {
            // Extend existing subscription
            $subscription->update([
                'wa_package_id' => $package->id,
                'expires_at' => $subscription->expires_at && $subscription->expires_at->isFuture() 
                    ? $subscription->expires_at->addDays($package->duration_days) 
                    : $expiresAt,
                'is_active' => true,
            ]);
        } else {
            $subscription = UserWaSubscription::create([
                'user_id' => $user->id,
                'wa_package_id' => $package->id,
                'session_id' => $sessionId,
                'api_key' => $apiKey,
                'status' => 'disconnected',
                'messages_sent_today' => 0,
                'messages_sent_week' => 0,
                'messages_sent_month' => 0,
                'daily_reset_at' => Carbon::now()->endOfDay(),
                'weekly_reset_at' => Carbon::now()->endOfWeek(),
                'monthly_reset_at' => Carbon::now()->endOfMonth(),
                'expires_at' => $expiresAt,
                'is_active' => true,
            ]);
        }

        return new JsonResponse([
            'success' => true,
            'message' => 'Berhasil berlangganan paket WhatsApp Gateway!',
            'subscription' => $subscription->load('package'),
        ]);
    }

    /**
     * Get message history logs for the current user.
     */
    public function logs(Request $request): JsonResponse
    {
        $user = $request->user();
        $logs = WaMessageLog::where('user_id', $user->id)
            ->orderBy('created_at', 'desc')
            ->take(50)
            ->get();

        return new JsonResponse([
            'logs' => $logs,
        ]);
    }

    /**
     * Regenerate API Key for WhatsApp integration.
     */
    public function regenerateApiKey(Request $request): JsonResponse
    {
        $user = $request->user();
        $subscription = UserWaSubscription::where('user_id', $user->id)->first();

        if (!$subscription) {
            throw new DisplayException('Subscription tidak ditemukan.');
        }

        $subscription->update([
            'api_key' => 'wa_api_' . Str::random(32),
        ]);

        return new JsonResponse([
            'success' => true,
            'api_key' => $subscription->api_key,
            'message' => 'API Key berhasil diperbarui!',
        ]);
    }

    /**
     * Request WhatsApp Pairing Code for linking phone number.
     */
    public function requestPairingCode(Request $request): JsonResponse
    {
        $request->validate([
            'phone' => 'required|string',
        ]);

        $user = $request->user();
        $subscription = UserWaSubscription::where('user_id', $user->id)
            ->where('is_active', true)
            ->first();

        if (!$subscription) {
            throw new DisplayException('Anda belum memiliki langganan paket WhatsApp Gateway yang aktif.');
        }

        $phone = preg_replace('/[^0-9]/', '', $request->input('phone'));

        try {
            $response = Http::timeout(10)->post("{$this->botUrl}/api/start", [
                'number' => $phone,
                'session_id' => $subscription->session_id,
            ]);

            $data = $response->json();
            if ($response->successful() && ($data['success'] ?? false)) {
                $subscription->update([
                    'phone_number' => $phone,
                    'status' => $data['status'] ?? 'pairing',
                ]);

                return new JsonResponse([
                    'success' => true,
                    'pairingCode' => $data['pairingCode'] ?? null,
                    'status' => $data['status'] ?? 'pairing',
                    'message' => 'Pairing code berhasil dibuat! Masukkan kode ini di WhatsApp Anda.',
                ]);
            }

            throw new DisplayException($data['message'] ?? 'Gagal membuat pairing code.');
        } catch (\Throwable $e) {
            throw new DisplayException('Tidak dapat terhubung ke WhatsApp Service: ' . $e->getMessage());
        }
    }

    /**
     * Disconnect / Logout and Delete WhatsApp Session.
     */
    public function disconnect(Request $request): JsonResponse
    {
        $user = $request->user();
        $subscription = UserWaSubscription::where('user_id', $user->id)->first();

        if ($subscription) {
            try {
                Http::post("{$this->botUrl}/api/stop", [
                    'session_id' => $subscription->session_id,
                ]);
            } catch (\Throwable $e) {}

            $subscription->update([
                'status' => 'disconnected',
                'phone_number' => null,
            ]);
        }

        return new JsonResponse([
            'success' => true,
            'message' => 'Sesi WhatsApp berhasil diputuskan & dihapus.',
        ]);
    }
    public function sendMessage(Request $request): JsonResponse
    {
        $apiKey = $request->header('X-WA-API-KEY') ?: $request->input('api_key');
        
        if ($apiKey) {
            $subscription = UserWaSubscription::with('package')
                ->where('api_key', $apiKey)
                ->where('is_active', true)
                ->first();
        } else {
            $user = $request->user();
            $subscription = UserWaSubscription::with('package')
                ->where('user_id', $user->id)
                ->where('is_active', true)
                ->first();
        }

        if (!$subscription) {
            throw new DisplayException('Subscription WhatsApp Gateway tidak aktif atau API Key salah.');
        }

        // Check if subscription has expired
        if ($subscription->expires_at && Carbon::now()->isAfter($subscription->expires_at)) {
            $subscription->update(['is_active' => false]);
            throw new DisplayException('Masa aktif paket WhatsApp Gateway Anda telah habis.');
        }

        $package = $subscription->package;
        if ($package) {
            // Check Daily Limit
            if ($package->daily_limit > 0 && $subscription->messages_sent_today >= $package->daily_limit) {
                throw new DisplayException('Limit pesan harian Anda telah tercapai (' . $package->daily_limit . ' pesan/hari).');
            }
            // Check Weekly Limit
            if ($package->weekly_limit > 0 && $subscription->messages_sent_week >= $package->weekly_limit) {
                throw new DisplayException('Limit pesan mingguan Anda telah tercapai (' . $package->weekly_limit . ' pesan/minggu).');
            }
            // Check Monthly Limit
            if ($package->monthly_limit > 0 && $subscription->messages_sent_month >= $package->monthly_limit) {
                throw new DisplayException('Limit pesan bulanan Anda telah tercapai (' . $package->monthly_limit . ' pesan/bulan).');
            }
        }

        $request->validate([
            'recipient' => 'required|string',
            'message' => 'required|string',
        ]);

        $recipient = preg_replace('/[^0-9]/', '', $request->input('recipient'));
        $message = trim($request->input('message'));

        // Send via Node.js Gateway service
        try {
            $res = Http::timeout(5)->post("{$this->botUrl}/api/send-message", [
                'session_id' => $subscription->session_id,
                'recipient' => $recipient,
                'message' => $message,
            ]);

            $isSuccess = $res->successful() && ($res->json('success') ?? true);
        } catch (\Throwable $e) {
            $isSuccess = false;
        }

        if ($isSuccess) {
            // Increment Quota Counter
            $subscription->increment('messages_sent_today');
            $subscription->increment('messages_sent_week');
            $subscription->increment('messages_sent_month');

            // Log Message
            WaMessageLog::create([
                'subscription_id' => $subscription->id,
                'user_id' => $subscription->user_id,
                'recipient' => $recipient,
                'message' => $message,
                'status' => 'sent',
            ]);

            return new JsonResponse([
                'success' => true,
                'message' => 'Pesan WhatsApp berhasil dikirim!',
                'quota' => [
                    'sent_today' => $subscription->messages_sent_today,
                    'daily_limit' => $package ? $package->daily_limit : 0,
                ],
            ]);
        }

        throw new DisplayException('Gagal mengirim pesan WhatsApp. Pastikan bot terhubung atau hubungi Admin.');
    }
}
