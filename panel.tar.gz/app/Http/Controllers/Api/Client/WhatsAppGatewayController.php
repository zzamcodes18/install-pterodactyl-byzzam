<?php

namespace Pterodactyl\Http\Controllers\Api\Client;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Pterodactyl\Models\WaPackage;
use Pterodactyl\Models\UserWaSubscription;
use Pterodactyl\Models\WaMessageLog;
use Pterodactyl\Models\StoreOrder;
use Pterodactyl\Models\StoreDiscount;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;
use Pterodactyl\Exceptions\DisplayException;
use Illuminate\Support\Str;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Http;

class WhatsAppGatewayController extends ClientApiController
{
    private string $botUrl = 'http://127.0.0.1:3001';

    public function __construct(private SettingsRepositoryInterface $settings)
    {
        parent::__construct();
    }

    private function generatePayment($user, int $amount, string $referenceId, string $description)
    {
        $projectId = $this->settings->get('transaksikita::project_id');
        $publicKey = $this->settings->get('transaksikita::public_key');
        $secretKey = $this->settings->get('transaksikita::secret_key');

        if (empty($projectId) || empty($publicKey) || empty($secretKey)) {
            throw new DisplayException('Payment Gateway belum dikonfigurasi oleh Admin.');
        }

        $ch = curl_init('https://transaksikita.com/api/v1/create-payment');
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'X-PROJECT-ID: ' . $projectId,
                'X-PUBLIC-KEY: ' . $publicKey,
                'Authorization: Bearer ' . $secretKey,
            ],
            CURLOPT_POSTFIELDS => json_encode([
                'amount' => $amount,
                'customerName' => $user->name_first . ' ' . $user->name_last,
                'description' => $description,
                'expiredMinutes' => 10,
                'referenceId' => $referenceId,
            ]),
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $decoded = json_decode($response, true);

        if ($httpCode === 200 && isset($decoded['success']) && $decoded['success']) {
            return $decoded['data']['paymentId'];
        }

        throw new DisplayException($decoded['message'] ?? 'Gagal membuat pembayaran dengan payment gateway.');
    }

    /**
     * Auto-reset quotas and check expiration for a subscription.
     */
    private function refreshSubscription(UserWaSubscription $subscription): UserWaSubscription
    {
        $now = Carbon::now();

        if (!$subscription->daily_reset_at || $now->isAfter($subscription->daily_reset_at)) {
            $subscription->messages_sent_today = 0;
            $subscription->daily_reset_at = $now->copy()->endOfDay();
        }

        if (!$subscription->weekly_reset_at || $now->isAfter($subscription->weekly_reset_at)) {
            $subscription->messages_sent_week = 0;
            $subscription->weekly_reset_at = $now->copy()->endOfWeek();
        }

        if (!$subscription->monthly_reset_at || $now->isAfter($subscription->monthly_reset_at)) {
            $subscription->messages_sent_month = 0;
            $subscription->monthly_reset_at = $now->copy()->endOfMonth();
        }

        // Check expiration
        if ($subscription->expires_at && $now->isAfter($subscription->expires_at)) {
            $subscription->is_active = false;
        }

        $subscription->save();

        return $subscription;
    }

    /**
     * Get all user WhatsApp subscriptions, active packages, and usage quota statistics.
     */
    public function index(Request $request): JsonResponse
    {
        $user = $request->user();

        $subscriptions = UserWaSubscription::with('package')
            ->where('user_id', $user->id)
            ->get();

        // Auto reset quotas for all subscriptions
        foreach ($subscriptions as $subscription) {
            $this->refreshSubscription($subscription);
        }

        $packages = WaPackage::where('is_active', true)->get();

        return new JsonResponse([
            'subscriptions' => $subscriptions,
            'packages' => $packages,
            'balance' => $user->store_balance ?? 0,
        ]);
    }

    /**
     * Get a single subscription by ID (must belong to the authenticated user).
     */
    public function show(Request $request, int $id): JsonResponse
    {
        $user = $request->user();

        $subscription = UserWaSubscription::with('package')
            ->where('user_id', $user->id)
            ->where('id', $id)
            ->firstOrFail();

        $this->refreshSubscription($subscription);

        return new JsonResponse([
            'subscription' => $subscription,
        ]);
    }

    /**
     * Purchase or renew a WhatsApp Gateway commercial plan with direct payment & discount support.
     */
    public function purchase(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'package_id' => 'required|integer|exists:wa_packages,id',
            'discount_code' => 'nullable|string',
        ]);

        $user = $request->user();
        $package = WaPackage::where('is_active', true)->findOrFail($validated['package_id']);

        $totalCost = $package->price;
        $discountModel = null;

        if (!empty($validated['discount_code'])) {
            $discountModel = StoreDiscount::where('code', strtoupper($validated['discount_code']))->first();
            if ($discountModel && $discountModel->isValid()) {
                $discountAmount = $totalCost * ($discountModel->discount_percent / 100);
                $totalCost = max(0, (int) round($totalCost - $discountAmount));
            } else {
                throw new DisplayException('Kode diskon tidak valid atau sudah kedaluwarsa.');
            }
        }

        $referenceId = 'WAGATEWAY-' . $user->id . '-' . time() . '-' . Str::random(5);

        // Handle Free Purchase (Discount 100%)
        if ($totalCost <= 0) {
            $paymentId = 'FREE-' . Str::random(10);
            
            StoreOrder::create([
                'user_id' => $user->id,
                'type' => 'wa_gateway',
                'data' => [
                    'package_id' => $package->id,
                    'duration_days' => $package->duration_days,
                ],
                'amount' => 0,
                'reference_id' => $referenceId,
                'payment_id' => $paymentId,
                'status' => 'paid',
            ]);

            if ($discountModel) {
                $discountModel->increment('uses');
            }

            $subscription = $this->activateSubscription($user, $package);

            return new JsonResponse([
                'success' => true,
                'message' => 'Berhasil berlangganan paket WhatsApp Gateway!',
                'data' => [
                    'paymentId' => 'FREE',
                    'referenceId' => $referenceId,
                ],
                'subscription' => $subscription->load('package'),
            ]);
        }

        // Direct Payment via Payment Gateway (Transaksikita)
        $paymentId = $this->generatePayment($user, $totalCost, $referenceId, 'Purchase WA Gateway Plan: ' . $package->name);

        StoreOrder::create([
            'user_id' => $user->id,
            'type' => 'wa_gateway',
            'data' => [
                'package_id' => $package->id,
                'duration_days' => $package->duration_days,
            ],
            'amount' => $totalCost,
            'reference_id' => $referenceId,
            'payment_id' => $paymentId,
            'status' => 'pending',
        ]);

        if ($discountModel) {
            $discountModel->increment('uses');
        }

        return new JsonResponse([
            'success' => true,
            'data' => [
                'paymentId' => $paymentId,
                'referenceId' => $referenceId,
            ]
        ]);
    }

    /**
     * Helper to activate or extend WhatsApp Subscription for a user.
     */
    public function activateSubscription($user, WaPackage $package): UserWaSubscription
    {
        $sessionId = 'user_' . $user->id . '_' . Str::random(8);
        $apiKey = 'wa_api_' . Str::random(32);
        $expiresAt = Carbon::now()->addDays($package->duration_days);

        // Always create a new subscription (multi-instance support)
        $subscription = UserWaSubscription::create([
            'user_id' => $user->id,
            'wa_package_id' => $package->id,
            'session_id' => $sessionId,
            'api_key' => $apiKey,
            'status' => 'disconnected',
            'messages_sent_today' => 0,
            'messages_sent_week' => 0,
            'messages_sent_month' => 0,
            'daily_reset_at' => Carbon::now()->endOfDay(),
            'weekly_reset_at' => Carbon::now()->endOfWeek(),
            'monthly_reset_at' => Carbon::now()->endOfMonth(),
            'expires_at' => $expiresAt,
            'is_active' => true,
        ]);

        return $subscription;
    }

    /**
     * Get message history logs for a specific subscription.
     */
    public function logs(Request $request, int $id): JsonResponse
    {
        $user = $request->user();

        // Verify subscription belongs to user
        $subscription = UserWaSubscription::where('user_id', $user->id)
            ->where('id', $id)
            ->firstOrFail();

        $logs = WaMessageLog::where('subscription_id', $subscription->id)
            ->orderBy('created_at', 'desc')
            ->take(50)
            ->get();

        return new JsonResponse([
            'logs' => $logs,
        ]);
    }

    /**
     * Regenerate API Key for a specific WhatsApp subscription.
     */
    public function regenerateApiKey(Request $request, int $id): JsonResponse
    {
        $user = $request->user();
        $subscription = UserWaSubscription::where('user_id', $user->id)
            ->where('id', $id)
            ->firstOrFail();

        $subscription->update([
            'api_key' => 'wa_api_' . Str::random(32),
        ]);

        return new JsonResponse([
            'success' => true,
            'api_key' => $subscription->api_key,
            'message' => 'API Key berhasil diperbarui!',
        ]);
    }

    /**
     * Request WhatsApp Pairing Code for a specific subscription.
     */
    public function requestPairingCode(Request $request, int $id): JsonResponse
    {
        $request->validate([
            'phone' => 'required|string',
        ]);

        $user = $request->user();
        $subscription = UserWaSubscription::where('user_id', $user->id)
            ->where('id', $id)
            ->where('is_active', true)
            ->firstOrFail();

        $phone = preg_replace('/[^0-9]/', '', $request->input('phone'));

        try {
            $response = Http::timeout(15)->post("{$this->botUrl}/api/start", [
                'number' => $phone,
                'session_id' => $subscription->session_id,
                'force' => true,
            ]);

            $data = $response->json();
            if ($response->successful() && ($data['success'] ?? false)) {
                $subscription->update([
                    'phone_number' => $phone,
                    'status' => $data['status'] ?? 'pairing',
                ]);

                return new JsonResponse([
                    'success' => true,
                    'pairingCode' => $data['pairingCode'] ?? null,
                    'status' => $data['status'] ?? 'pairing',
                    'message' => 'Pairing code berhasil dibuat! Masukkan kode ini di WhatsApp Anda.',
                ]);
            }

            throw new DisplayException($data['message'] ?? 'Gagal membuat pairing code.');
        } catch (DisplayException $e) {
            throw $e;
        } catch (\Throwable $e) {
            throw new DisplayException('Tidak dapat terhubung ke WhatsApp Service: ' . $e->getMessage());
        }
    }

    /**
     * Disconnect / Logout and Delete WhatsApp Session for a specific subscription.
     */
    public function disconnect(Request $request, int $id): JsonResponse
    {
        $user = $request->user();
        $subscription = UserWaSubscription::where('user_id', $user->id)
            ->where('id', $id)
            ->firstOrFail();

        try {
            Http::post("{$this->botUrl}/api/stop", [
                'session_id' => $subscription->session_id,
            ]);
        } catch (\Throwable $e) {}

        $subscription->update([
            'status' => 'disconnected',
            'phone_number' => null,
        ]);

        return new JsonResponse([
            'success' => true,
            'message' => 'Sesi WhatsApp berhasil diputuskan & dihapus.',
        ]);
    }
    /**
     * Send WhatsApp message via a specific subscription or API key.
     */
    public function sendMessage(Request $request, ?int $id = null): JsonResponse
    {
        $apiKey = $request->header('X-WA-API-KEY') ?: $request->input('api_key');
        
        if ($apiKey) {
            // External API auth via API key
            $subscription = UserWaSubscription::with('package')
                ->where('api_key', $apiKey)
                ->where('is_active', true)
                ->first();
        } elseif ($id) {
            // User auth via subscription ID
            $user = $request->user();
            $subscription = UserWaSubscription::with('package')
                ->where('user_id', $user->id)
                ->where('id', $id)
                ->where('is_active', true)
                ->first();
        } else {
            throw new DisplayException('Subscription ID atau API Key diperlukan.');
        }

        if (!$subscription) {
            throw new DisplayException('Subscription WhatsApp Gateway tidak aktif atau API Key salah.');
        }

        // Check if subscription has expired
        if ($subscription->expires_at && Carbon::now()->isAfter($subscription->expires_at)) {
            $subscription->update(['is_active' => false]);
            throw new DisplayException('Masa aktif paket WhatsApp Gateway Anda telah habis.');
        }

        $package = $subscription->package;
        if ($package) {
            // Check Daily Limit
            if ($package->daily_limit > 0 && $subscription->messages_sent_today >= $package->daily_limit) {
                throw new DisplayException('Limit pesan harian Anda telah tercapai (' . $package->daily_limit . ' pesan/hari).');
            }
            // Check Weekly Limit
            if ($package->weekly_limit > 0 && $subscription->messages_sent_week >= $package->weekly_limit) {
                throw new DisplayException('Limit pesan mingguan Anda telah tercapai (' . $package->weekly_limit . ' pesan/minggu).');
            }
            // Check Monthly Limit
            if ($package->monthly_limit > 0 && $subscription->messages_sent_month >= $package->monthly_limit) {
                throw new DisplayException('Limit pesan bulanan Anda telah tercapai (' . $package->monthly_limit . ' pesan/bulan).');
            }
        }

        $request->validate([
            'recipient' => 'required|string',
            'message' => 'required|string',
        ]);

        $recipient = preg_replace('/[^0-9]/', '', $request->input('recipient'));
        $message = trim($request->input('message'));

        // Send via Node.js Gateway service
        try {
            $res = Http::timeout(5)->post("{$this->botUrl}/api/send-message", [
                'session_id' => $subscription->session_id,
                'recipient' => $recipient,
                'message' => $message,
            ]);

            $isSuccess = $res->successful() && ($res->json('success') ?? true);
        } catch (\Throwable $e) {
            $isSuccess = false;
        }

        if ($isSuccess) {
            // Increment Quota Counter
            $subscription->increment('messages_sent_today');
            $subscription->increment('messages_sent_week');
            $subscription->increment('messages_sent_month');

            // Log Message
            WaMessageLog::create([
                'subscription_id' => $subscription->id,
                'user_id' => $subscription->user_id,
                'recipient' => $recipient,
                'message' => $message,
                'status' => 'sent',
            ]);

            return new JsonResponse([
                'success' => true,
                'message' => 'Pesan WhatsApp berhasil dikirim!',
                'quota' => [
                    'sent_today' => $subscription->messages_sent_today,
                    'daily_limit' => $package ? $package->daily_limit : 0,
                ],
            ]);
        }

        throw new DisplayException('Gagal mengirim pesan WhatsApp. Pastikan bot terhubung atau hubungi Admin.');
    }
}
