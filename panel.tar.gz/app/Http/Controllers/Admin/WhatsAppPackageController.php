<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\WaPackage;
use Prologue\Alerts\AlertsMessageBag;

class WhatsAppPackageController extends Controller
{
    public function __construct(private AlertsMessageBag $alert)
    {
    }

    /**
     * Display listing of WhatsApp Gateway commercial packages.
     */
    public function index(): View
    {
        return view('admin.whatsapp.packages', [
            'packages' => WaPackage::all(),
        ]);
    }

    /**
     * Store a newly created WhatsApp package.
     */
    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'name' => 'required|string|max:191',
            'description' => 'nullable|string',
            'price' => 'required|integer|min:0',
            'duration_days' => 'required|integer|min:1',
            'daily_limit' => 'required|integer|min:0',
            'weekly_limit' => 'required|integer|min:0',
            'monthly_limit' => 'required|integer|min:0',
            'is_active' => 'boolean',
        ]);

        $data['is_active'] = $request->has('is_active');

        WaPackage::create($data);

        $this->alert->success('Successfully created new WhatsApp Gateway package.')->flash();

        return redirect()->route('admin.whatsapp.packages');
    }

    /**
     * Update the specified WhatsApp package.
     */
    public function update(Request $request, $package): RedirectResponse
    {
        $packageModel = WaPackage::findOrFail($package);

        $data = $request->validate([
            'name' => 'required|string|max:191',
            'description' => 'nullable|string',
            'price' => 'required|integer|min:0',
            'duration_days' => 'required|integer|min:1',
            'daily_limit' => 'required|integer|min:0',
            'weekly_limit' => 'required|integer|min:0',
            'monthly_limit' => 'required|integer|min:0',
            'is_active' => 'boolean',
        ]);

        $data['is_active'] = $request->has('is_active');

        $packageModel->update($data);

        $this->alert->success('Successfully updated WhatsApp Gateway package.')->flash();

        return redirect()->route('admin.whatsapp.packages');
    }

    /**
     * Remove the specified WhatsApp package.
     */
    public function destroy($package): RedirectResponse
    {
        $packageModel = WaPackage::findOrFail($package);
        $packageModel->delete();

        $this->alert->success('Successfully deleted WhatsApp Gateway package.')->flash();

        return redirect()->route('admin.whatsapp.packages');
    }
}
