import express from 'express';
import cors from 'cors';
import { 
    makeWASocket, 
    useMultiFileAuthState, 
    DisconnectReason, 
    Browsers, 
    fetchLatestBaileysVersion, 
    jidNormalizedUser 
} from '@whiskeysockets/baileys';
import pino from 'pino';
import axios from 'axios';
import fs from 'fs';
import path from 'path';

// Read Pterodactyl .env
const envPath = path.resolve('../.env');
let APP_URL = 'http://127.0.0.1';
let WA_BOT_SECRET = 'pterodactyl_wa_secret';

if (fs.existsSync(envPath)) {
    const envContent = fs.readFileSync(envPath, 'utf8');
    const urlMatch = envContent.match(/^APP_URL=(.*)$/m);
    if (urlMatch) APP_URL = urlMatch[1].replace(/['"]/g, '').trim();
    
    const secretMatch = envContent.match(/^WA_BOT_SECRET=(.*)$/m);
    if (secretMatch) WA_BOT_SECRET = secretMatch[1].replace(/['"]/g, '').trim();
}

const app = express();
app.use(cors());
app.use(express.json());

let sock = null;
let currentStatus = 'offline';
let reconnectTimeout = null;

const pm2Logs = [];
const originalLog = console.log;
const originalError = console.error;

function pushLog(type, args) {
    const msg = args.map(a => typeof a === 'object' ? JSON.stringify(a) : a).join(' ');
    pm2Logs.push(`[${new Date().toISOString()}] [${type.toUpperCase()}] ${msg}`);
    if (pm2Logs.length > 100) pm2Logs.shift();
}

console.log = function(...args) {
    pushLog('info', args);
    originalLog.apply(console, args);
};
console.error = function(...args) {
    pushLog('error', args);
    originalError.apply(console, args);
};

function formatPhoneNumber(num) {
    if (!num) return '';
    let clean = num.toString().replace(/[^0-9]/g, '');
    if (clean.startsWith('0')) {
        clean = '62' + clean.slice(1);
    }
    return clean;
}

let isStarting = false;

async function startBot(targetNumber) {
    if (isStarting) {
        console.log('[SYSTEM] startBot is already running, skipping duplicate call.');
        return null;
    }
    isStarting = true;

    try {
        if (reconnectTimeout) {
            clearTimeout(reconnectTimeout);
            reconnectTimeout = null;
        }

        if (sock) {
            try {
                sock.ev?.removeAllListeners();
                if (sock.ws && typeof sock.ws.close === 'function') sock.ws.close();
            } catch (_) {}
            sock = null;
        }

        const { state, saveCreds } = await useMultiFileAuthState('auth_info_baileys');
        const { version: v } = await fetchLatestBaileysVersion();

        sock = makeWASocket({
            printQRInTerminal: false,
            auth: state,
            version: v,
            browser: Browsers.macOS('Safari'),
            syncFullHistory: true,
            markOnlineOnConnect: true,
            logger: pino({ level: 'silent' })
        });

        sock.ev.on('creds.update', saveCreds);

        sock.ev.on('connection.update', async ({ connection, lastDisconnect }) => {
            if (!connection) return;
            if (connection === 'close') {
                const reason = lastDisconnect?.error?.output?.statusCode;
                console.log(`[CONNECTION] Closed (statusCode: ${reason})`);

                // Jika WhatsApp di HP berhasil diverifikasi (restartRequired / 515), segera reconnect ke sesi aktif
                if (reason === DisconnectReason.restartRequired) {
                    console.log('[SYSTEM] Restart Required (Handshake pairing berhasil), reconnecting...');
                    currentStatus = 'connecting';
                    await startBot();
                    return;
                }

                // Jika belum terdaftar dan koneksi terputus saat pairing, JANGAN loop reconnect agar tidak Connection Closed
                if (!sock?.authState?.creds?.registered) {
                    console.log(`[SYSTEM] Sesi belum terdaftar dan koneksi ditutup (${reason}). Tidak reconnect otomatis.`);
                    currentStatus = 'offline';
                    return;
                }

                switch (reason) {
                    case DisconnectReason.badSession:
                    case DisconnectReason.loggedOut:
                        console.log('[SYSTEM] Device Logged Out atau Bad Session, membersihkan sesi...');
                        currentStatus = 'offline';
                        if (sock) {
                            try { sock.ev?.removeAllListeners(); if (sock.ws && typeof sock.ws.close === 'function') sock.ws.close(); } catch (_) {}
                            sock = null;
                        }
                        if (fs.existsSync('auth_info_baileys')) {
                            try { fs.rmSync('auth_info_baileys', { recursive: true, force: true }); } catch (_) {}
                        }
                        break;
                    case DisconnectReason.connectionReplaced:
                        console.log('[SYSTEM] Connection Replaced, sesi dibuka di tempat lain.');
                        currentStatus = 'offline';
                        if (sock) {
                            try { sock.ev?.removeAllListeners(); if (sock.ws && typeof sock.ws.close === 'function') sock.ws.close(); } catch (_) {}
                            sock = null;
                        }
                        break;
                    default:
                        console.log(`[SYSTEM] Terputus (${reason}). Menghubungkan ulang dalam 3 detik...`);
                        currentStatus = 'connecting';
                        if (reconnectTimeout) clearTimeout(reconnectTimeout);
                        reconnectTimeout = setTimeout(async () => {
                            await startBot();
                        }, 3000);
                        break;
                }
            } else if (connection === 'open') {
                currentStatus = 'online';
                const userPhone = sock.user?.id?.split(':')[0] || '';
                console.log(`[SYSTEM] Bot WhatsApp berhasil terkoneksi${userPhone ? ` (${userPhone})` : ''}!`);
                try {
                    await sock.sendPresenceUpdate('available');
                } catch (e) {}
            }
        });

    sock.ev.on('messages.upsert', async (m) => {
        if (m.type !== 'notify') return;
        const msg = m.messages[0];
        if (!msg.message || msg.key.fromMe) return;

        // Auto read
        try {
            await sock.readMessages([msg.key]);
            await sock.sendPresenceUpdate('available', msg.key.remoteJid);
        } catch (e) {}

        // Normalize JID to ensure we get the clean phone number without device suffixes.
        // Use participantPn or senderPn if available (when WhatsApp hides the real JID behind a @lid)
        const senderJid = msg.key.participantPn || msg.key.senderPn || msg.key.participant || msg.key.remoteJid;
        const normalizedJid = jidNormalizedUser(senderJid);
        const sender = normalizedJid.split('@')[0];
        const text = msg.message.conversation || msg.message.extendedTextMessage?.text || '';

        if (!text) return;

        console.log(`[MESSAGE] Incoming from Raw: ${msg.key.remoteJid} | Participant: ${msg.key.participant} | Parsed Sender: ${sender}`);
        if (msg.key.remoteJid.includes('@lid') || (msg.key.participant && msg.key.participant.includes('@lid'))) {
            console.log("[DEBUG LID] Full Message Payload:", JSON.stringify(msg, null, 2));
        }

        try {
            // Forward to Pterodactyl Laravel Webhook
            const response = await axios.post(`${APP_URL}/api/bot/webhook`, {
                secret: WA_BOT_SECRET,
                phone: sender,
                remoteJid: msg.key.remoteJid,
                message: text
            }, {
                headers: { 'Accept': 'application/json' },
                validateStatus: false // Prevent throwing error on 4xx/5xx
            });

            if (response.data && response.data.reply) {
                const systemName = response.data.botName || 'BOT SYSTEM';
                if (response.data.simulateProgress) {
                    // Send initial loading message
                    const sentMsg = await sock.sendMessage(msg.key.remoteJid, { 
                        text: `⚡ *${systemName}* ⚡\n\n⏳ [▒▒▒▒▒▒▒▒▒▒] 0%\n> Memproses perintah...` 
                    }, { quoted: msg });

                    const progressSteps = [
                        `⚡ *${systemName}* ⚡\n\n⏳ [███▒▒▒▒▒▒▒] 30%\n> Mengambil data server & database...`,
                        `⚡ *${systemName}* ⚡\n\n⏳ [███████▒▒▒] 70%\n> Menyusun rincian informasi...`,
                        `⚡ *${systemName}* ⚡\n\n⏳ [██████████] 100%\n> *Selesai!* Menampilkan menu...`
                    ];

                    for (const stepText of progressSteps) {
                        await new Promise(r => setTimeout(r, 600));
                        if (sentMsg?.key) {
                            await sock.sendMessage(msg.key.remoteJid, {
                                text: stepText,
                                edit: sentMsg.key
                            }).catch(() => {});
                        }
                    }

                    await new Promise(r => setTimeout(r, 500));
                    if (sentMsg?.key) {
                        await sock.sendMessage(msg.key.remoteJid, {
                            text: response.data.reply,
                            edit: sentMsg.key
                        }).catch(async () => {
                            await sock.sendMessage(msg.key.remoteJid, { text: response.data.reply }, { quoted: msg });
                        });
                    }
                } else {
                    await sock.sendMessage(msg.key.remoteJid, { text: response.data.reply }, { quoted: msg });
                }
            }

            if (response.data && response.data.action) {
                const action = response.data.action;
                
                if (action === 'join_group') {
                    try {
                        const groupId = await sock.groupAcceptInvite(response.data.invite_code);
                        const groupMetadata = await sock.groupMetadata(groupId);
                        
                        await sock.sendMessage(msg.key.remoteJid, { text: `✅ Berhasil bergabung ke grup: *${groupMetadata.subject}*` });
                        
                        // Tell Laravel to save it
                        await axios.post(`${APP_URL}/api/bot/group-update`, {
                            secret: WA_BOT_SECRET,
                            action: 'joined',
                            group_jid: groupId,
                            group_name: groupMetadata.subject
                        }, { validateStatus: false });
                        
                    } catch (e) {
                        await sock.sendMessage(msg.key.remoteJid, { text: `❌ Gagal bergabung ke grup: ${e.message}` });
                    }
                }

                if (action === 'set_group') {
                    try {
                        const groupId = response.data.group_jid || msg.key.remoteJid;
                        const groupMetadata = await sock.groupMetadata(groupId);
                        
                        await axios.post(`${APP_URL}/api/bot/group-update`, {
                            secret: WA_BOT_SECRET,
                            action: 'joined',
                            group_jid: groupId,
                            group_name: groupMetadata.subject
                        }, { validateStatus: false });
                        
                    } catch (e) {
                        console.error('Failed to get group metadata for setgroup:', e.message);
                    }
                }

                if (action === 'broadcast') {
                    const targets = response.data.targets;
                    const bcastMsg = response.data.message_text;
                    let successCount = 0;
                    
                    for (const t of targets) {
                        try {
                            const [result] = await sock.onWhatsApp(t);
                            if (result && result.exists) {
                                await sock.sendMessage(result.jid, { text: `📢 *BROADCAST PANEL*\n\n${bcastMsg}` });
                                successCount++;
                            }
                        } catch (e) {}
                        // Delay to avoid ban
                        await new Promise(r => setTimeout(r, 2000));
                    }
                    
                    await sock.sendMessage(msg.key.remoteJid, { text: `✅ Pesan massal berhasil dikirim ke ${successCount} kontak.` });
                }

                if (action === 'restart_bot') {
                    process.exit(0); // PM2 will automatically restart it
                }
            }

            // Handle private DM reply (send credentials/backup details privately)
            if (response.data && response.data.private_reply && response.data.target_phone) {
                const targetPhone = response.data.target_phone;
                const privateText = response.data.private_reply;

                try {
                    // Normalize phone to JID format
                    let targetJid = targetPhone;
                    if (!targetJid.includes('@')) {
                        targetJid = targetJid + '@s.whatsapp.net';
                    }

                    // Verify the number exists on WhatsApp
                    const [result] = await sock.onWhatsApp(targetPhone);
                    if (result && result.exists) {
                        targetJid = result.jid;
                    }

                    await sock.sendMessage(targetJid, { text: privateText });
                    console.log(`[PRIVATE DM] Sent private message to ${targetPhone}`);
                } catch (dmErr) {
                    console.error(`[PRIVATE DM] Failed to send private message to ${targetPhone}:`, dmErr.message);
                    // Notify in the original chat that DM failed
                    await sock.sendMessage(msg.key.remoteJid, { 
                        text: `⚠️ Gagal ngirim pesan private menyang ${targetPhone}. Pastikan nomor terdaftar di WhatsApp.` 
                    });
                }
            }
        } catch (err) {
            console.error('Failed to send webhook to Pterodactyl:', err.message);
            await sock.sendMessage(msg.key.remoteJid, { text: 'Bot sedang mengalami gangguan internal.' });
        }
    });

    if (!sock.authState.creds.registered && targetNumber) {
        currentStatus = 'pairing';
        try {
            const formattedTarget = formatPhoneNumber(targetNumber);
            console.log(`[PAIRING] Mempersiapkan pairing code untuk nomor ${formattedTarget}...`);

            // Tunggu hingga WebSocket aktif (ReadyState === 1 / OPEN)
            let attempts = 0;
            while (sock?.ws?.readyState !== 1 && attempts < 25) {
                await new Promise(resolve => setTimeout(resolve, 200));
                attempts++;
            }

            // Jeda 2 detik setelah socket open agar handshake Noise protocol WhatsApp matang
            await new Promise(resolve => setTimeout(resolve, 2000));

            let rawCode;
            try {
                rawCode = await sock.requestPairingCode(formattedTarget);
            } catch (err) {
                console.warn(`[PAIRING] Percobaan 1 gagal (${err.message}), mencoba ulang dalam 2 detik...`);
                await new Promise(resolve => setTimeout(resolve, 2000));
                rawCode = await sock.requestPairingCode(formattedTarget);
            }

            const code = (rawCode && rawCode.length === 8) 
                ? (rawCode.slice(0, 4) + '-' + rawCode.slice(4, 8)) 
                : (rawCode?.match(/.{1,4}/g)?.join('-') || rawCode);

            console.log(`[PAIRING] Pairing code didapatkan: ${code}`);
            return code;
        } catch (err) {
            console.error('Pairing code error:', err);
            throw new Error('Gagal mendapatkan pairing code, pastikan nomor benar dan layanan WA tidak memblokir. Pesan: ' + err.message);
        }
    }

    return null;
    } finally {
        isStarting = false;
    }
}

app.post('/api/start', async (req, res) => {
    const { number, force } = req.body;
    isStarting = false;

    try {
        if (reconnectTimeout) {
            clearTimeout(reconnectTimeout);
            reconnectTimeout = null;
        }

        // If bot is online and registered, but user explicitly wants to re-pair with a new number or force reset
        if ((currentStatus === 'online' || (sock && sock.authState?.creds?.registered)) && (force || number)) {
            if (sock) {
                try {
                    if (sock.ws && typeof sock.ws.close === 'function') sock.ws.close();
                } catch (e) {}
                sock = null;
            }
            currentStatus = 'offline';
            if (fs.existsSync('auth_info_baileys')) {
                try { fs.rmSync('auth_info_baileys', { recursive: true, force: true }); } catch (e) {}
            }
        } else if (currentStatus === 'online') {
            return res.json({ success: false, message: 'Bot is already online.' });
        }

        // Clear session if creating new pairing code to prevent conflict
        if (number) {
            if (sock) {
                try {
                    if (sock.ws && typeof sock.ws.close === 'function') sock.ws.close();
                } catch (e) {}
                sock = null;
            }
            if (fs.existsSync('auth_info_baileys')) {
                try { fs.rmSync('auth_info_baileys', { recursive: true, force: true }); } catch (e) {}
            }

            const cleanNumber = formatPhoneNumber(number);
            if (!cleanNumber || cleanNumber.length < 7) {
                return res.json({ success: false, message: 'Nomor telepon tidak valid. Gunakan format internasional (contoh: 628123456789 atau 08123456789).' });
            }
            const code = await startBot(cleanNumber);
            return res.json({ success: true, pairingCode: code, status: 'pairing' });
        }

        if (!sock || !sock.authState?.creds?.registered) {
            return res.json({ success: false, message: 'Number is required for pairing.' });
        } else {
            await startBot();
            return res.json({ success: true, status: 'connecting' });
        }
    } catch (err) {
        return res.json({ success: false, message: err.message });
    }
});

app.post('/api/stop', async (req, res) => {
    let message = 'Bot dihentikan.';
    if (reconnectTimeout) {
        clearTimeout(reconnectTimeout);
        reconnectTimeout = null;
    }
    if (sock) {
        try {
            if (sock.ws && typeof sock.ws.close === 'function') sock.ws.close();
        } catch (e) {}
        sock = null;
    }
    currentStatus = 'offline';
    
    // Always clear auth state to allow new pairing
    if (fs.existsSync('auth_info_baileys')) {
        try { fs.rmSync('auth_info_baileys', { recursive: true, force: true }); } catch (e) {}
        message = 'Sesi dihapus dan bot dihentikan.';
    }
    
    return res.json({ success: true, status: 'offline', message });
});

app.post('/api/clear', async (req, res) => {
    if (reconnectTimeout) {
        clearTimeout(reconnectTimeout);
        reconnectTimeout = null;
    }
    if (sock) {
        try {
            if (sock.ws && typeof sock.ws.close === 'function') sock.ws.close();
        } catch (e) {}
        sock = null;
    }
    currentStatus = 'offline';
    
    if (fs.existsSync('auth_info_baileys')) {
        try { fs.rmSync('auth_info_baileys', { recursive: true, force: true }); } catch (e) {}
    }
    
    return res.json({ success: true, status: 'offline', message: 'Sesi berhasil dihapus secara paksa.' });
});

app.get('/api/status', (req, res) => {
    const isOnline = currentStatus === 'online';
    const isRegistered = isOnline && (sock?.authState?.creds?.registered || false);
    res.json({ status: currentStatus, registered: isRegistered });
});

app.get('/api/group-info', async (req, res) => {
    const groupId = req.query.groupId;
    if (!sock || !sock.authState.creds.registered || !groupId) {
        return res.json({ success: false, message: 'Bot offline or no groupId' });
    }
    try {
        const metadata = await sock.groupMetadata(groupId);
        return res.json({ success: true, subject: metadata.subject, id: metadata.id });
    } catch (e) {
        return res.json({ success: false, message: e.message });
    }
});

app.get('/api/logs', (req, res) => {
    res.json({ success: true, logs: pm2Logs });
});

app.post('/api/leave-group', async (req, res) => {
    const { groupId } = req.body;
    if (sock && groupId) {
        try {
            await sock.groupLeave(groupId);
            return res.json({ success: true, message: 'Berhasil keluar grup' });
        } catch (e) {
            return res.json({ success: false, message: e.message });
        }
    }
    return res.json({ success: false, message: 'Bot offline atau tidak ada groupId' });
});

app.post('/api/add-participant', async (req, res) => {
    const { groupId, number } = req.body;
    if (!sock || !sock.authState.creds.registered) {
        return res.json({ success: false, message: 'Bot is offline.' });
    }
    try {
        let targetJid = number;
        if (!number.endsWith('@s.whatsapp.net')) {
             targetJid = number + '@s.whatsapp.net';
        }
        await sock.groupParticipantsUpdate(groupId, [targetJid], "add");
        return res.json({ success: true });
    } catch (e) {
        return res.json({ success: false, message: e.message });
    }
});

app.post('/api/send-message', async (req, res) => {
    const { number, message, mentions } = req.body;
    if (!sock || !sock.authState.creds.registered) {
        return res.json({ success: false, message: 'Bot is offline or not registered.' });
    }
    if (!number || !message) {
        return res.json({ success: false, message: 'Number and message are required.' });
    }

    try {
        let targetJid = number;
        // Check if it's a group
        if (number.endsWith('@g.us')) {
            targetJid = number;
        } else {
            const [result] = await sock.onWhatsApp(number);
            if (result && result.exists) {
                targetJid = result.jid;
            } else {
                return res.json({ success: false, message: 'WhatsApp number not found/registered on WA.' });
            }
        }
        
        let msgOptions = { text: message };
        if (mentions && Array.isArray(mentions)) {
            msgOptions.mentions = mentions;
        }

        await sock.sendMessage(targetJid, msgOptions);
        return res.json({ success: true, message: 'Message sent successfully.' });
    } catch (e) {
        return res.json({ success: false, message: e.message });
    }
});

const PORT = 3001;
app.listen(PORT, () => {
    console.log(`WhatsApp Bot Service running on port ${PORT}`);
    // Auto-start if credentials exist
    if (fs.existsSync('auth_info_baileys/creds.json')) {
        startBot();
    }
});
